import csv
import numpy as np
from scipy.stats import skew
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn import metrics
import pickle

np.set_printoptions(suppress=True)

featureMatrix = []
label = []

# Meal.csv contains all the meal and no meal data for all the 5 patients combined
with open('Meal.csv', newline='') as csvfile:
    dataCGM = list(csv.reader(csvfile))
for row in range(0, 510):
    x = []
    y = []
    for i in range(0, 30):
        if dataCGM[row][i] == '' or dataCGM[row][i] == 'NaN' or dataCGM[row][i] == 'nan':
            continue
        y.append(float(dataCGM[row][i]))
    if len(y) != 0:
        featureMatrix.append([np.sqrt(np.mean(np.array(y)**2)), np.mean(y), np.std(y), max(y), skew(y), np.var(y)])
        if row < 255:
            label.append(1)
        else:
            label.append(0)
# print(featureMatrix)
# feature_names=['RMS','Mean','STD','Max','Skew','Variance']
# target_names=['No Meal','Meal']
featureMatrix = np.array(featureMatrix)
label = np.array(label)

# Feature matrix in a object named X
X = featureMatrix
# response vector in a object named y
y = label


X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.16,random_state=82)
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

svcclassifier = SVC(kernel = 'rbf', random_state = 0)
svcclassifier.fit(X_train, y_train)

# Predicting the Test set results
y_pred = svcclassifier.predict(X_test)
# print(y_pred)
confusionMatrix = metrics.confusion_matrix(y_test, y_pred)
# print(cm)

#finding accuracy from the confusion matrix.
shape = confusionMatrix.shape
corrPred = 0
falsePred = 0

for row in range(shape[0]):
    for col in range(shape[1]):
        if row == col:
            corrPred += confusionMatrix[row, col]
        else:
            falsePred += confusionMatrix[row, col]

print('Correct predictions:', corrPred)
print('False predictions:', falsePred)
print("Precision:",metrics.precision_score(y_test, y_pred))
print("Recall:",metrics.recall_score(y_test, y_pred))
kernelRbfAccuracy = corrPred/(confusionMatrix.sum())
print ('Accuracy of the SVC Classification is: ', corrPred/(confusionMatrix.sum()))

filename = 'finalized_model_SVM.sav'
pickle.dump(svcclassifier, open(filename, 'wb'))














