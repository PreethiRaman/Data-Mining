import csv
import numpy as np
from scipy.stats import skew
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn import metrics
import pickle

np.set_printoptions(suppress=True)

featureMatrix = []
filLoc = input("Enter the path of the CSV file")
with open(filLoc, newline='') as csvfile:
    dataCGM = list(csv.reader(csvfile))  
for row in range(0, len(dataCGM)):
    y = []
    for i in range(0, 30):
        if dataCGM[row][i] == '' or dataCGM[row][i] == 'NaN' or dataCGM[row][i] == 'nan':
            continue
        y.append(float(dataCGM[row][i]))  
    if len(y) != 0:
        featureMatrix.append([np.sqrt(np.mean(np.array(y)**2)), np.mean(y), np.std(y), max(y), skew(y), np.var(y)])
classes = {0: 'No Meal', 1: 'Meal'}
feature_names = ['RMS', 'Range', 'Mean', 'STD', 'Max', 'Skew', 'Variance']
target_names = ['No Meal', 'Meal']
featureMatrix = np.array(featureMatrix)
loaded_model = pickle.load(open('finalized_model_SVM.sav', 'rb'))
x_new = featureMatrix
y_predict = loaded_model.predict(x_new)
labelNumber = 1
label = []
with open('meal_label.csv', mode='w') as meal_label_file:
    meal_label_writer = csv.writer(meal_label_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL) 
    for k in y_predict:
        print("Label ", labelNumber, ":", k)
        meal_label_writer.writerow([labelNumber, classes[k], k])
        labelNumber = labelNumber+1
        label.append(k)
print("----------------------------------------------Label Vector---------------------------------------------")
print(label)

    