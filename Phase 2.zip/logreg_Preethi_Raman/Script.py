# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 00:21:21 2019

@author: DELL
"""


import csv
import numpy as np
from scipy.stats import skew
from scipy.stats import kurtosis
from sklearn.model_selection import train_test_split
from sklearn import metrics
import pickle
from sklearn.metrics import average_precision_score
from sklearn.linear_model import LogisticRegression

np.set_printoptions(suppress=True)
featureMatrix=[]
label=[]

with open('C:\dm\Meal.csv', newline='') as csvfile:
    dataCGM = list(csv.reader(csvfile)) 

for row in range(0,510):        
    y=[]
    for i in range(0,30):
        if dataCGM[row][i]=='' or dataCGM[row][i]=='NaN' or dataCGM[row][i]=='nan':
            continue
        y.append(float(dataCGM[row][i]))  

    if(len(y)!=0):
        featureMatrix.append([np.sqrt(np.mean(np.array(y)**2)),np.mean(y),np.std(y),max(y),skew(y),np.var(y)])
        if(row<255):
            label.append(1)
        else:
            label.append(0)

feature_names=['RMS','Mean','STD','Max','Skew','Variance']
target_names=['No Meal','Meal']
featureMatrix=np.array(featureMatrix)
label=np.array(label)
X = featureMatrix
y = label
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=2)

logreg = LogisticRegression()
logreg.fit(X_train,y_train)

logregPickle = open('logregpickle_file', 'wb') 
pickle.dump(logreg, logregPickle)
classes = {0:'No Meal',1:'Meal'}
loaded_model = pickle.load(open('logregpickle_file', 'rb'))
x_new = featureMatrix
y_predict = loaded_model.predict(X_test)
score=metrics.accuracy_score(y_test,y_predict)
print("The accuracy is:",score*100)
print("Precision:",metrics.precision_score(y_test, y_predict))
print("Recall:",metrics.recall_score(y_test, y_predict))


