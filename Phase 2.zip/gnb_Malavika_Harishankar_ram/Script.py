# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 00:01:44 2019

@author: Malavika Hari shankar ram
"""

import csv
import numpy as np
from scipy.stats import skew
from sklearn.model_selection import train_test_split
from sklearn import metrics
import pickle
from sklearn.naive_bayes import GaussianNB


np.set_printoptions(suppress=True)
featureMatrix=[]
classlabel=[]

with open('C:\dm\Meal.csv', newline='') as csvfile:
    data = list(csv.reader(csvfile)) 

for row in range(0,510):        
    y=[]
    for i in range(0,30):
        if data[row][i]=='' or data[row][i]=='NaN' or data[row][i]=='nan':
            continue
        y.append(float(data[row][i]))  

    if(len(y)!=0):
        featureMatrix.append([np.sqrt(np.mean(np.array(y)**2)),np.mean(y),np.std(y),max(y),skew(y),np.var(y)])
        if(row<255):
            classlabel.append(1)
        else:
            classlabel.append(0)



feature_names=['RMS','Mean','STD','Max','Skew','Variance']
target_names=['No Meal','Meal']
featureMatrix=np.array(featureMatrix)
classlabel=np.array(classlabel)
X = featureMatrix
y = classlabel
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=2)
gnb = GaussianNB()
gnb.fit(X_train, y_train)
gnbPickle = open('gnbpickle_file', 'wb') 
pickle.dump(gnb, gnbPickle)
classes = {0:'No Meal',1:'Meal'}
loaded_model = pickle.load(open('gnbpickle_file', 'rb'))
x_new = featureMatrix
y_predict = loaded_model.predict(X_test)
score=metrics.accuracy_score(y_test,y_predict)
print("The accuracy is:",score*100)
print("Precision:",metrics.precision_score(y_test, y_predict))
print("Recall:",metrics.recall_score(y_test, y_predict))



