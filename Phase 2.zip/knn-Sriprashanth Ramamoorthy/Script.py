import csv
import numpy as np
from scipy.stats import skew
from scipy.stats import kurtosis
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
import pickle
from sklearn.metrics import average_precision_score



np.set_printoptions(suppress=True)
featureMatrix=[]
label=[]

with open('/Users/prashanth/Documents/projects/Data Mining/Phase1/DataFolder/Meal.csv', newline='') as csvfile:
    dataCGM = list(csv.reader(csvfile)) 

for row in range(0,510):        
    y=[]
    for i in range(0,30):
        if dataCGM[row][i]=='' or dataCGM[row][i]=='NaN' or dataCGM[row][i]=='nan':
            continue
        y.append(float(dataCGM[row][i]))  

    if(len(y)!=0):
        featureMatrix.append([np.sqrt(np.mean(np.array(y)**2)),max(y)-min(y),np.mean(y),np.std(y),max(y),skew(y),np.var(y),kurtosis(y)])
        if(row<255):
            label.append(1)
        else:
            label.append(0)



feature_names=['RMS','Range','Mean','STD','Max','Skew','Variance','Kurtosis']
target_names=['No Meal','Meal']
featureMatrix=np.array(featureMatrix)
label=np.array(label)
X = featureMatrix
y = label
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=2)
# k_range = range(1,200)

# for k in k_range:
#     knn = KNeighborsClassifier(n_neighbors=k)
#     knn.fit(X,y)
#     knnPickle = open('knnpickle_file', 'wb') 
#     pickle.dump(knn, knnPickle)
#     classes = {0:'No Meal',1:'Meal'}
#     loaded_model = pickle.load(open('knnpickle_file', 'rb'))
#     x_new = featureMatrix
#     y_predict = loaded_model.predict(X_test)
#     score=metrics.accuracy_score(y_test,y_predict)
#     print(k,"The accuracy is:",score)


knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X,y)
knnPickle = open('knnpickle_file', 'wb') 
pickle.dump(knn, knnPickle)
classes = {0:'No Meal',1:'Meal'}
loaded_model = pickle.load(open('knnpickle_file', 'rb'))
x_new = featureMatrix
y_predict = loaded_model.predict(X_test)
score=metrics.accuracy_score(y_test,y_predict)

print("The accuracy is:",score*100)
print("The precision is:",metrics.precision_score(y_test, y_predict)*100)
print("The recall:",metrics.recall_score(y_test, y_predict)*100)

# for k in y_predict:
#     print(classes[k])
# print(classes[y_predict[0]])
# print(classes[y_predict[1]])


