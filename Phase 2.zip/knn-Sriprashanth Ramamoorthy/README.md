# Meal Label Predictor

Phase-2 implementation of **Data Mining** (CSE 572) project. 

# Installing
Dependencies:  
  * Python 3
  * numpy 
  * scipy
  * scikit-learn 
  To setup all dependencies, create a python virtual environment in  Visual Studio Code.
  The dependencies can be imported using
    pip install -r requirements.txt 

# Running 

There is module:
  * Script.py
  
  The module comprises of building the feature Matrix of the training data set and also,training and saving a KNN classification machine.
  To execute the tasks in module:
```sh
python -W ignore Script.py
```

  * Test.py
    The module comprises of building the feature Matrix of the test data set and using the previously buil KNN classification machine to predict the label of the test data.
    Input is the file location in CSV format.
    Example:
    /Users/prashanth/Documents/projects/Data Mining/Phase1/DataFolder/Meal.csv
    The Output is printed in the console in the format of : Label No. : 0/1
    0-No Meal
    1-Meal
    The printed output is also saved in a csv file named meal_label.csv in the directory in which the Test.py is run
    To execute the tasks in module:
```sh
python -W ignore Test.py
```
  



  
